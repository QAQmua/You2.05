import SwiftUI
import PhotosUI

// MARK: - 专属编辑配置面板
struct EditChatDraftWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var mgr = ChatDraftWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @State private var pickerItem: PhotosPickerItem? = nil
    
    private let colors = ["#F4F5F7", "#FFFFFF", "#000000", "#F2EBE5", "#EAF0F8", "#FCE7EC", "#E8F5E9", "#3A3A3C"]
    private let textColors = ["#3A3A3C", "#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#FF9500"]
    private let cardColors = ["#FFFFFF", "#F9F9F9", "#1C1C1E", "#F4F5F7", "#FCE7EC"]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    // 1. 顶部 2×2 卡片实时悬浮预览 (可直接在此测试丝滑收缩)
                    ChatDraftWidget2x2View(manager: mgr, showDashedBorder: true)
                        .frame(width: 160 * s, height: 160 * s)
                        .padding(.top, 16)
                        .padding(.bottom, 6)
                        .shadow(color: .black.opacity(0.08), radius: 10, y: 4)
                    
                    // 2. 头像更换与管理
                    VStack(alignment: .leading, spacing: 12) {
                        Text("头像设置".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                        
                        PhotosPicker(selection: $pickerItem, matching: .images, photoLibrary: .shared()) {
                            HStack {
                                Label("更换头像照片".tr, systemImage: "photo.badge.plus")
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.semibold))
                                    .foregroundColor(.secondary)
                            }
                        }
                        .foregroundColor(.primary)
                        
                        if mgr.avatarData != nil {
                            Divider()
                            Button(role: .destructive, action: {
                                withAnimation { mgr.avatarData = nil }
                            }) {
                                Label("清空已选图片 (恢复默认)".tr, systemImage: "trash")
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                        }
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 3. 草稿文字与光标设置
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Text("草稿文本 (桌面可直接点击编辑)".tr)
                                .font(.system(size: 13, weight: appearance.systemFontWeight))
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                            Spacer()
                            Button("恢复原图内容".tr) {
                                withAnimation {
                                    mgr.draftContent = ChatDraftWidgetManager.defaultDraftText
                                }
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                        }
                        
                        // 统一标准灰底胶囊槽输入框
                        ZStack(alignment: .topLeading) {
                            TextEditor(text: $mgr.draftContent)
                                .font(.subheadline)
                                .frame(minHeight: 90)
                                .scrollContentBackground(.hidden)
                                .background(Color.clear)
                        }
                        .padding(10)
                        .background(Color(UIColor.tertiarySystemFill))
                        .cornerRadius(10)
                        
                        Toggle("显示首行闪烁竖线光标 (|)".tr, isOn: $mgr.showCursor)
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                        
                        Divider()
                        
                        WidgetColorPaletteRow(
                            title: "正文字体颜色".tr,
                            selectedHex: mgr.textColorHex,
                            presets: textColors,
                            currentColor: Color(hex: mgr.textColorHex),
                            onSelectHex: { mgr.textColorHex = $0 },
                            onPickColor: { mgr.textColorHex = $0.toHex() }
                        )
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 4. 背景与卡片外观配置
                    VStack(alignment: .leading, spacing: 14) {
                        Text("背景与卡片外观".tr)
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                        
                        Picker("", selection: $mgr.bgColorMode) {
                            Text("自选颜色 (默认)".tr).tag("color")
                            Text("完全透明".tr).tag("transparent")
                        }
                        .pickerStyle(.segmented)
                        
                        if mgr.bgColorMode == "color" {
                            WidgetColorPaletteRow(
                                title: "底板背景颜色".tr,
                                selectedHex: mgr.bgColorHex,
                                presets: colors,
                                currentColor: Color(hex: mgr.bgColorHex),
                                onSelectHex: { mgr.bgColorHex = $0 },
                                onPickColor: { mgr.bgColorHex = $0.toHex() }
                            )
                            
                            Divider()
                            
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("背景不透明度".tr)
                                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(mgr.bgOpacity * 100))%")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                                Slider(value: $mgr.bgOpacity, in: 0.0...1.0, step: 0.05)
                            }
                        }
                        
                        Divider()
                        
                        WidgetColorPaletteRow(
                            title: "输入框卡片底色".tr,
                            selectedHex: mgr.cardBgHex,
                            presets: cardColors,
                            currentColor: Color(hex: mgr.cardBgHex),
                            onSelectHex: { mgr.cardBgHex = $0 },
                            onPickColor: { mgr.cardBgHex = $0.toHex() }
                        )
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                }
                .padding(.bottom, 32)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("草稿卡片 (2×2)".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .task(id: pickerItem) {
                if let d = try? await pickerItem?.loadTransferable(type: Data.self) {
                    withAnimation { mgr.avatarData = d }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}
