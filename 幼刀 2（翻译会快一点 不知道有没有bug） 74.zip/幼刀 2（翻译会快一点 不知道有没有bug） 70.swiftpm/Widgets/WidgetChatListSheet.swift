// 📄 文件 2：Widgets/WidgetChatListSheet.swift
import SwiftUI
import PhotosUI

// MARK: - 消息小卡片专属编辑面板
struct EditChatListWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var mgr = ChatListWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @State private var p1: PhotosPickerItem? = nil
    @State private var p2: PhotosPickerItem? = nil
    
    private let colors = ["#000000", "#FFFFFF", "#3A3A3C", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let borderColors = ["#E5E5EA", "#000000", "#FFFFFF", "#8E8E93", "#007AFF", "#FF2D55", "#FF9500"]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    // 1. 顶部 2×2 卡片实时悬浮预览
                    ChatListWidget2x2View(manager: mgr, showDashedBorder: true)
                        .frame(width: 160 * s, height: 160 * s)
                        .padding(.top, 16)
                        .padding(.bottom, 6)
                        .shadow(color: .black.opacity(0.08), radius: 10, y: 4)
                    
                    // 2. 背景与时间同步
                    VStack(alignment: .leading, spacing: 12) {
                        Text("背景样式".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                        Picker("", selection: $mgr.bgColorMode) {
                            Text("纯白 (默认)".tr).tag("white")
                            Text("原版深黑".tr).tag("black")
                            Text("透明背景".tr).tag("transparent")
                        }
                        .pickerStyle(.segmented)
                        
                        Divider()
                        
                        Toggle("自动同步现实日期与时间".tr, isOn: $mgr.autoFollowRealTime)
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 🌟 3. 头像圆角大小设置
                    VStack(alignment: .leading, spacing: 10) {
                        Text("头像样式".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("头像圆角".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Text(mgr.avatarCornerRadius >= 13 ? "圆形 (默认)".tr : (mgr.avatarCornerRadius == 0 ? "直角".tr : String(format: "%.0f pt", mgr.avatarCornerRadius)))
                                    .font(.caption).foregroundColor(.secondary)
                            }
                            Slider(value: $mgr.avatarCornerRadius, in: 0.0...14.0, step: 1.0)
                        }
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 4. 联系人圆框描边与自定义圆角
                    VStack(alignment: .leading, spacing: 14) {
                        Toggle(isOn: $mgr.hasItemCard) {
                            Label("联系人列表圆框描边".tr, systemImage: "square.dashed").font(.system(size: 15, weight: appearance.systemFontWeight))
                        }
                        if mgr.hasItemCard {
                            Divider()
                            WidgetColorPaletteRow(title: "圆框底色".tr, selectedHex: mgr.itemCardBgHex, presets: colors, currentColor: Color(hex: mgr.itemCardBgHex), onSelectHex: { mgr.itemCardBgHex = $0 }, onPickColor: { mgr.itemCardBgHex = $0.toHex() })
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("圆框圆角".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.0f pt", mgr.itemCardCornerRadius)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $mgr.itemCardCornerRadius, in: 2.0...16.0, step: 1.0)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("描边粗细".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.1f pt", mgr.itemCardBorderWidth)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $mgr.itemCardBorderWidth, in: 0.4...3.0, step: 0.1)
                            }
                            Divider()
                            WidgetColorPaletteRow(title: "描边颜色".tr, selectedHex: mgr.itemCardBorderHex, presets: borderColors, currentColor: Color(hex: mgr.itemCardBorderHex), onSelectHex: { mgr.itemCardBorderHex = $0 }, onPickColor: { mgr.itemCardBorderHex = $0.toHex() })
                        }
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 5. 字体颜色配置
                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            Text("字体颜色配置".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Spacer()
                            if !mgr.mainTextColorHex.isEmpty || !mgr.subTextColorHex.isEmpty || !mgr.timeColorHex.isEmpty {
                                Button("恢复默认配色".tr) {
                                    withAnimation {
                                        mgr.mainTextColorHex = ""
                                        mgr.subTextColorHex = ""
                                        mgr.timeColorHex = ""
                                    }
                                }
                                .font(.caption)
                                .foregroundColor(.blue)
                            }
                        }
                        WidgetColorPaletteRow(title: "主要文字 (昵称/电量/星期)".tr, selectedHex: mgr.mainTextColorHex, presets: colors, currentColor: !mgr.mainTextColorHex.isEmpty ? Color(hex: mgr.mainTextColorHex) : (mgr.bgColorMode == "black" ? .white : .black), onSelectHex: { mgr.mainTextColorHex = $0 }, onPickColor: { mgr.mainTextColorHex = $0.toHex() })
                        Divider()
                        WidgetColorPaletteRow(title: "消息正文颜色".tr, selectedHex: mgr.subTextColorHex, presets: colors, currentColor: !mgr.subTextColorHex.isEmpty ? Color(hex: mgr.subTextColorHex) : (mgr.bgColorMode == "black" ? .white.opacity(0.85) : Color(hex: "#2C2C2E")), onSelectHex: { mgr.subTextColorHex = $0 }, onPickColor: { mgr.subTextColorHex = $0.toHex() })
                        Divider()
                        WidgetColorPaletteRow(title: "时间与日期颜色".tr, selectedHex: mgr.timeColorHex, presets: colors, currentColor: !mgr.timeColorHex.isEmpty ? Color(hex: mgr.timeColorHex) : Color(hex: "#8E8E93"), onSelectHex: { mgr.timeColorHex = $0 }, onPickColor: { mgr.timeColorHex = $0.toHex() })
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 6. 顶部栏配置
                    VStack(alignment: .leading, spacing: 12) {
                        Text("顶部栏配置".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                        input(placeholder: "contact: // 456076", text: $mgr.contactText)
                        input(placeholder: "电量 (如: 60%)", text: $mgr.batteryText)
                    }
                    .padding(16)
                    .background(Color(UIColor.secondarySystemGroupedBackground))
                    .cornerRadius(18)
                    .padding(.horizontal, 16)
                    
                    // 7. 联系人配置
                    contactSection(title: "第一位联系人 (小雨呆咪)".tr, name: $mgr.name1, msg: $mgr.message1, time: $mgr.time1, status: $mgr.status1, avatarData: mgr.avatar1Data, pickerItem: $p1, onClear: { mgr.avatar1Data = nil })
                    contactSection(title: "第二位联系人 (流泪猫猫头)".tr, name: $mgr.name2, msg: $mgr.message2, time: $mgr.time2, status: $mgr.status2, avatarData: mgr.avatar2Data, pickerItem: $p2, onClear: { mgr.avatar2Data = nil })
                }
                .padding(.bottom, 32)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("消息小卡片 (2×2)".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .task(id: p1) { if let d = try? await p1?.loadTransferable(type: Data.self) { withAnimation { mgr.avatar1Data = d }; UINotificationFeedbackGenerator().notificationOccurred(.success) } }
            .task(id: p2) { if let d = try? await p2?.loadTransferable(type: Data.self) { withAnimation { mgr.avatar2Data = d }; UINotificationFeedbackGenerator().notificationOccurred(.success) } }
        }
        .presentationDetents([.medium, .large])
    }
    
    private func contactSection(title: String, name: Binding<String>, msg: Binding<String>, time: Binding<String>, status: Binding<String>, avatarData: Data?, pickerItem: Binding<PhotosPickerItem?>, onClear: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.system(size: 15, weight: appearance.systemFontWeight))
            PhotosPicker(selection: pickerItem, matching: .images, photoLibrary: .shared()) {
                HStack {
                    Label("更换头像".tr, systemImage: "person.crop.circle.badge.plus")
                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold))
                        .foregroundColor(.secondary)
                }
            }
            .foregroundColor(.primary)
            
            if avatarData != nil {
                Divider()
                Button(role: .destructive, action: { withAnimation { onClear() } }) {
                    Label("清空已选头像".tr, systemImage: "trash").font(.system(size: 15, weight: appearance.systemFontWeight))
                }
            }
            
            Divider()
            input(placeholder: "昵称".tr, text: name)
            input(placeholder: "消息内容".tr, text: msg)
            HStack(spacing: 12) {
                if !mgr.autoFollowRealTime { input(placeholder: "时间".tr, text: time) }
                input(placeholder: "状态".tr, text: status)
            }
        }
        .padding(16)
        .background(Color(UIColor.secondarySystemGroupedBackground))
        .cornerRadius(18)
        .padding(.horizontal, 16)
    }
    
    private func input(placeholder: String, text: Binding<String>) -> some View {
        TextField(placeholder, text: text)
            .font(.subheadline)
            .padding(10)
            .background(Color(UIColor.tertiarySystemFill))
            .cornerRadius(10)
    }
}
