import SwiftUI
import UIKit

// 📄 系统核心环境：缩放比率、颜色转换、字重转换与通用排版
public var uiScale: CGFloat {
    let screenW = UIScreen.main.bounds.width
    let isPhone = (UIDevice.current.userInterfaceIdiom == .phone) || (screenW <= 500)
    return isPhone ? 1.16 : 1.0
}

extension Color {
    init(hex: String) {
        let cleanHex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: cleanHex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch cleanHex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 229, 229, 234)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255.0,
            green: Double(g) / 255.0,
            blue: Double(b) / 255.0,
            opacity: Double(a) / 255.0
        )
    }
    
    func toHex() -> String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        let uiColor = UIColor(self)
        if uiColor.getRed(&r, green: &g, blue: &b, alpha: &a) {
            let redInt = Int(max(0, min(255, lroundf(Float(r * 255.0)))))
            let greenInt = Int(max(0, min(255, lroundf(Float(g * 255.0)))))
            let blueInt = Int(max(0, min(255, lroundf(Float(b * 255.0)))))
            return String(format: "#%02X%02X%02X", redInt, greenInt, blueInt)
        }
        return "#000000"
    }
}

extension Font.Weight {
    static func from(name: String) -> Font.Weight {
        switch name {
        case "light": return .light
        case "regular": return .regular
        case "medium": return .medium
        case "semibold": return .semibold
        case "bold": return .bold
        case "heavy": return .heavy
        default: return .regular
        }
    }
}

extension Font {
    static var size64: Font { .system(size: 64) }
}

struct FlowLayout: Layout {
    var spacing: CGFloat = 8
    
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? 0
        var height: CGFloat = 0
        var currentX: CGFloat = 0
        var currentY: CGFloat = 0
        var maxHeightInRow: CGFloat = 0
        
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if currentX + size.width > width && currentX > 0 {
                currentX = 0
                currentY += maxHeightInRow + spacing
                maxHeightInRow = 0
            }
            maxHeightInRow = max(maxHeightInRow, size.height)
            currentX += size.width + spacing
        }
        height = currentY + maxHeightInRow
        return CGSize(width: width, height: height)
    }
    
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var currentX: CGFloat = bounds.minX
        var currentY: CGFloat = bounds.minY
        var maxHeightInRow: CGFloat = 0
        
        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if currentX + size.width > bounds.maxX && currentX > bounds.minX {
                currentX = bounds.minX
                currentY += maxHeightInRow + spacing
                maxHeightInRow = 0
            }
            view.place(at: CGPoint(x: currentX, y: currentY), proposal: ProposedViewSize(size))
            maxHeightInRow = max(maxHeightInRow, size.height)
            currentX += size.width + spacing
        }
    }
}

// 🚀 核心：全局单例内存缓存器（下载一次永久常驻内存，彻底解决重绘闪烁）
@MainActor
final class PlaneIconCache: ObservableObject {
    static let shared = PlaneIconCache()
    @Published var image: UIImage? = nil
    private var isFetching = false
    
    private let urlString = "https://i.postimg.cc/MZhyyPCc/wu-biao-ti112-20261009181730.png"
    
    init() {
        loadImage()
    }
    
    func loadImage() {
        guard image == nil, !isFetching else { return }
        guard let url = URL(string: urlString) else { return }
        isFetching = true
        
        // 优先检查系统磁盘/内存缓存
        let request = URLRequest(url: url)
        if let cachedResponse = URLCache.shared.cachedResponse(for: request),
           let img = UIImage(data: cachedResponse.data) {
            self.image = img
            self.isFetching = false
            return
        }
        
        // 后台静默拉取并缓存
        URLSession.shared.dataTask(with: request) { [weak self] data, response, _ in
            guard let data = data, let img = UIImage(data: data) else { return }
            if let response = response {
                URLCache.shared.storeCachedResponse(CachedURLResponse(response: response, data: data), for: request)
            }
            DispatchQueue.main.async {
                self?.image = img
                self?.isFetching = false
            }
        }.resume()
    }
}

// ✈️ 纯净零闪烁纸飞机组件（彻底消灭旧图标，拖动滑块零延迟直出）
struct InsSendPlaneIcon: View {
    var size: CGFloat = 16
    var color: Color = .secondary
    
    @ObservedObject private var cache = PlaneIconCache.shared
    
    var body: some View {
        Group {
            if let img = cache.image {
                // 🌟 使用蒙版模式，不管原图是白底还是黑底，强制染上你在组件配置的颜色
                color
                    .mask(
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                    )
            } else {
                // 🌟 未加载完成前保持透明占位，绝不乱闪任何多余图标
                Color.clear
                    .onAppear {
                        cache.loadImage()
                    }
            }
        }
        .frame(width: size, height: size)
    }
}
