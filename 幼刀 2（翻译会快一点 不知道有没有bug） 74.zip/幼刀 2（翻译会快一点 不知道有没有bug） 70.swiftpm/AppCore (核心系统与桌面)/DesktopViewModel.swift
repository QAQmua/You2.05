import SwiftUI

// 📄 桌面 24 格网格、Dock 栏与排版算法核心中心
@MainActor
class HomeScreenViewModel: ObservableObject {
    @Published var apps: [AppItem?] = []
    @Published var dockApps: [AppItem] = []
    @Published var isEditing: Bool = false
    @Published var isExpandingNewPage: Bool = false
    
    let pageSize: Int = 24
    private let gridKey = "App_HomeScreen_Grid24_Data_Clean"
    private let dockKey = "App_HomeScreen_Dock4_Data_Clean"
    private let saveQueue = DispatchQueue(label: "com.app.homescreen.saveQueue", qos: .utility)
    
    init() { loadData() }
    
    func isPageEmpty(_ page: Int) -> Bool {
        let start = page * pageSize
        let end = min(start + pageSize, apps.count)
        if start < end {
            let hasApp = apps[start..<end].contains(where: { $0 != nil })
            if hasApp { return false }
        }
        let hasWidget = WidgetRegistry.shared.activeManagers.contains { $0.isAddedToDesktop && $0.widgetPage == page }
        return !hasWidget
    }
    
    func totalPagesWithoutExtra() -> Int {
        var maxPage = 0
        if let lastIndex = apps.lastIndex(where: { $0 != nil }) {
            maxPage = max(maxPage, lastIndex / pageSize)
        }
        for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop {
            maxPage = max(maxPage, widget.widgetPage)
        }
        return max(1, maxPage + 1)
    }
    
    func totalPages() -> Int {
        let contentPages = totalPagesWithoutExtra()
        return isExpandingNewPage ? contentPages + 1 : contentPages
    }
    
    func triggerExpandNewPage() {
        isExpandingNewPage = true
        ensureCapacity(upToSlot: (totalPagesWithoutExtra() + 1) * pageSize)
    }
    
    func ensureCapacity(upToSlot slot: Int) {
        while apps.count <= slot { apps.append(nil) }
    }
    
    func compactPages() {
        isExpandingNewPage = false
        var p = 0
        while p < totalPagesWithoutExtra() - 1 {
            if isPageEmpty(p) {
                let start = p * pageSize
                let end = min(start + pageSize, apps.count)
                if start < apps.count { apps.removeSubrange(start..<end) }
                for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop && widget.widgetPage > p {
                    widget.widgetPage -= 1
                }
            } else { p += 1 }
        }
        
        let activePages = totalPagesWithoutExtra()
        let neededSlots = activePages * pageSize
        while apps.count > neededSlots && apps.last == nil { apps.removeLast() }
        while apps.count < neededSlots { apps.append(nil) }
        
        evictAppsUnderWidgets()
        saveApps()
    }
    
    func getCoveredIndices() -> Set<Int> {
        var covered = Set<Int>()
        for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop {
            let p = widget.widgetPage
            let r = widget.widgetRow
            let c = widget.widgetCol
            let pageBase = p * pageSize
            for i in 0..<widget.sizeRows {
                for j in 0..<widget.sizeCols {
                    let slotRow = r + i
                    let slotCol = c + j
                    if slotRow < 6 && slotCol < 4 {
                        covered.insert(pageBase + slotRow * 4 + slotCol)
                    }
                }
            }
        }
        return covered
    }
    
    func findAvailableSlot(forRows neededRows: Int, forCols neededCols: Int, preferPage: Int = 0) -> (page: Int, row: Int, col: Int) {
        let contentPages = totalPagesWithoutExtra()
        let candidateRows: [Int] = (neededRows >= 4) ? [0, 1, 2] : [0, 1, 2, 3, 4]
        let candidateCols: [Int] = (neededCols >= 4) ? [0] : [0, 2]
        
        var pageOrder: [Int] = [min(preferPage, max(0, contentPages - 1))]
        for p in 0..<contentPages where p != pageOrder[0] { pageOrder.append(p) }
        
        for p in pageOrder {
            var occupied = Array(repeating: Array(repeating: false, count: 4), count: 6)
            for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop && widget.widgetPage == p {
                for i in 0..<widget.sizeRows {
                    for j in 0..<widget.sizeCols {
                        let r = widget.widgetRow + i
                        let c = widget.widgetCol + j
                        if r < 6 && c < 4 { occupied[r][c] = true }
                    }
                }
            }
            
            for r in candidateRows {
                for c in candidateCols {
                    if r + neededRows <= 6 && c + neededCols <= 4 {
                        var canFit = true
                        for i in 0..<neededRows {
                            for j in 0..<neededCols {
                                if occupied[r + i][c + j] { canFit = false; break }
                            }
                            if !canFit { break }
                        }
                        if canFit { return (page: p, row: r, col: c) }
                    }
                }
            }
        }
        return (page: contentPages, row: 0, col: 0)
    }
    
    func evictAppsUnderWidgets(vacatedSlots: [Int] = []) {
        let covered = getCoveredIndices()
        let neededCount = max(totalPages(), 1) * pageSize
        while apps.count < neededCount { apps.append(nil) }
        
        var displacedApps: [AppItem] = []
        for i in 0..<apps.count {
            if covered.contains(i), let item = apps[i] {
                displacedApps.append(item)
                apps[i] = nil
            }
        }
        
        for app in displacedApps {
            if let freeSlot = (0..<apps.count).first(where: { !covered.contains($0) && apps[$0] == nil }) {
                apps[freeSlot] = app
            } else { apps.append(app) }
        }
        while apps.count < pageSize { apps.append(nil) }
        saveApps()
    }
    
    func loadData() {
        var loadedApps: [AppItem?] = []
        if let data = UserDefaults.standard.data(forKey: gridKey),
           let decoded = try? JSONDecoder().decode([AppItem?].self, from: data) {
            loadedApps = decoded
        }
        while loadedApps.count < pageSize { loadedApps.append(nil) }
        
        var loadedDock: [AppItem] = []
        if let data = UserDefaults.standard.data(forKey: dockKey),
           let decoded = try? JSONDecoder().decode([AppItem].self, from: data) {
            loadedDock = Array(decoded.prefix(4))
        }
        
        self.apps = loadedApps
        self.dockApps = loadedDock
        compactPages()
    }
    
    func deduplicateApps() {
        var seenIds = Set<String>()
        var uniqueDock: [AppItem] = []
        for item in dockApps {
            if !seenIds.contains(item.id) { seenIds.insert(item.id); uniqueDock.append(item) }
        }
        self.dockApps = uniqueDock
        for (index, item) in apps.enumerated() {
            if let item = item {
                if seenIds.contains(item.id) { apps[index] = nil }
                else { seenIds.insert(item.id) }
            }
        }
    }
    
    func saveApps() {
        let currentApps = self.apps
        let currentDock = self.dockApps
        let gKey = self.gridKey
        let dKey = self.dockKey
        saveQueue.async {
            if let data = try? JSONEncoder().encode(currentApps) { UserDefaults.standard.set(data, forKey: gKey) }
            if let data = try? JSONEncoder().encode(currentDock) { UserDefaults.standard.set(data, forKey: dKey) }
        }
    }
    
    func moveItem(from source: AppLocation, to destination: AppLocation) {
        guard source != destination else { return }
        let covered = getCoveredIndices()
        switch (source, destination) {
        case (.grid(let from), .grid(let to)):
            ensureCapacity(upToSlot: max(from, to))
            guard from < apps.count, to < apps.count, !covered.contains(to) else { return }
            let target = apps[to]
            apps[to] = apps[from]
            apps[from] = target
            
        case (.dock(let from), .dock(let to)):
            guard from < dockApps.count, to < dockApps.count, from != to else { return }
            let item = dockApps.remove(at: from)
            dockApps.insert(item, at: min(to, dockApps.count))
            
        case (.grid(let fromGrid), .dock(let toDock)):
            ensureCapacity(upToSlot: fromGrid)
            guard fromGrid < apps.count, let movingItem = apps[fromGrid] else { return }
            apps[fromGrid] = nil
            dockApps.removeAll(where: { $0.id == movingItem.id })
            if dockApps.count < 4 {
                dockApps.insert(movingItem, at: min(toDock, dockApps.count))
            } else {
                let safeIndex = min(toDock, dockApps.count - 1)
                let targetDockItem = dockApps[safeIndex]
                dockApps[safeIndex] = movingItem
                apps[fromGrid] = targetDockItem
            }
            
        case (.dock(let fromDock), .grid(let toGrid)):
            ensureCapacity(upToSlot: toGrid)
            guard fromDock < dockApps.count, toGrid < apps.count, !covered.contains(toGrid) else { return }
            let movingItem = dockApps.remove(at: fromDock)
            if let targetExisting = apps[toGrid] {
                if !dockApps.contains(where: { $0.id == targetExisting.id }) && dockApps.count < 4 {
                    dockApps.insert(targetExisting, at: min(fromDock, dockApps.count))
                }
            }
            apps[toGrid] = movingItem
        }
        deduplicateApps()
    }
    
    func slotsForPage(_ pageIndex: Int) -> [(index: Int, item: AppItem?)] {
        let start = pageIndex * pageSize
        let end = start + pageSize
        // 🌟 只改了这一句，纯安全读取，绝不在此刻意外扩充数组导致渲染死循环
        return (start..<end).map { index in
            let safeItem = index < apps.count ? apps[index] : nil
            return (index: index, item: safeItem)
        }
    }
    
    func resolveAllWidgetOverlaps(priority: DesktopWidgetManager? = nil) {
        let allActive = WidgetRegistry.shared.activeManagers.filter { $0.isAddedToDesktop }
        guard allActive.count > 1 else { return }
        
        var resolved: [DesktopWidgetManager] = []
        if let priority = priority, priority.isAddedToDesktop { resolved.append(priority) }
        
        let remaining = allActive.filter { other in
            if let p = priority { return other !== p }
            return true
        }
        
        for w in remaining {
            let collides = resolved.contains { isWidgetsOverlapping(w, $0) }
            if !collides {
                resolved.append(w)
            } else {
                let candidateCols = (w.sizeCols >= 4) ? [0] : [0, 2]
                let maxRow = max(0, 6 - w.sizeRows)
                let candidateRows = Array(0...maxRow)
                
                var placed = false
                var p = w.widgetPage
                while !placed && p < 10 {
                    let sortedRows = candidateRows.sorted { abs($0 - w.widgetRow) < abs($1 - w.widgetRow) }
                    for r in sortedRows {
                        for c in candidateCols {
                            let wouldCollide = resolved.contains { other in
                                guard other.widgetPage == p else { return false }
                                let r1 = r..<(r + w.sizeRows)
                                let r2 = other.widgetRow..<(other.widgetRow + other.sizeRows)
                                let c1 = c..<(c + w.sizeCols)
                                let c2 = other.widgetCol..<(other.widgetCol + other.sizeCols)
                                return r1.overlaps(r2) && c1.overlaps(c2)
                            }
                            if !wouldCollide {
                                w.widgetPage = p
                                w.widgetRow = r
                                w.widgetCol = c
                                resolved.append(w)
                                placed = true
                                break
                            }
                        }
                        if placed { break }
                    }
                    p += 1
                }
            }
        }
    }
    
    private func isWidgetsOverlapping(_ w1: DesktopWidgetManager, _ w2: DesktopWidgetManager) -> Bool {
        guard w1.isAddedToDesktop && w2.isAddedToDesktop else { return false }
        guard w1.widgetPage == w2.widgetPage else { return false }
        let r1 = w1.widgetRow..<(w1.widgetRow + w1.sizeRows)
        let r2 = w2.widgetRow..<(w2.widgetRow + w2.sizeRows)
        let c1 = w1.widgetCol..<(w1.widgetCol + w1.sizeCols)
        let c2 = w2.widgetCol..<(w2.widgetCol + w2.sizeCols)
        return r1.overlaps(r2) && c1.overlaps(c2)
    }
}
